<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPyhWsqZTIo1lZ5TEQsrLqtvD9XSdr640ReQiQ2qR2TTEyOdVDmxZkiOAVVvzyGbDrnYTd4Nf
4Z3IfHl7l0r/ndXSPRVJ4tkCaBpkknhJlkuhK3GlwRjYUV506PcDaqJBVMS0h/5DMfT+qK/ksPqa
JBEUn011MTDcsZIfJYW9Hlwgd3Hrww07XuvOiJslk61zQeOw1+v3kfR0PWLrky6ZwYjuFy/HtNeF
rKUxNMz++rubouvX8qz+oPcQXi6MpEVZjqgtrKyfeI9aPTtwsHbHkhwCmbFEmgzp//GWZx/Kgp8n
lP5rgu8dqdDy5PmIFYUS1dTxpzDYDGCxNU5VgtDXJ/gGesa+cEoLQWk5XEWBJSv6m4lAhgcnYr3+
Q41WkYmoaWIphWjTXiw7bUbkC98VITCk5ioFzYx9ClPe91ZoDWMM0caVnqBXh1RgblXYXhHM6UOO
N5BzzQK9s0FU0k+B2dvovN92VTmVznYfyOvXdqF+83L/HfWH9ldRVOytu+iJTvjNfobXfk4H1TVm
yq+sq2EMPPfkOiVcQ091bbpO/qn89prUpEgRo5yeiWgZELdG9qa2/7/75XNvnrdkCW16SZfVSXHB
iuaen5hTmSYtg2P62Q85RKDn1Wq8+5hDMD1r5ZYD88CWCR6gmfXvwXgyeWJ3GlJu0hcTXL1sVgty
QoTrrzAXwXubqBP4Q9dR1K+cOc+58FTeBKEB3i25DlYZ8XX7E8mGOHt44H29dgBfpglye+Kv2w19
rn6jRDoKSJv9h13TxpZJS3gsz3yKwezrQ6YkbQjuLUPnkEpeYKJpXSNfA4worFImJeESK9z07GVZ
cvxdUliz3+MSAggpAEuFzz+08zfJJISKqtWriEfzFsGVxlqNMNfJDK2HCr13Bhwe0QH8tPXyIYgL
85HjzAAKuiPrPny79GY76OsrBDu2GBekgGMJsUXSilYoIABh4himD6eSiNwwvBXd5ClmbHNlH1ax
dSsm909v6n+uGNXg9o+9cfHoIHJ4XuSoBuVbEw3pC7sdAtlXGcQg1ZT9ppIDOgzLTdB5WParB/gu
//go91e500==