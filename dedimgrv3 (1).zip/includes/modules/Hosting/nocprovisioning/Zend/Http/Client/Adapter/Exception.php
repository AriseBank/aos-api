<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPvJojzuiMGmHFKKY/Uunnln0Ko4UiJRlbxci97jXloKmtXJvtj/LTUmgn0iMSHyXVILAG055
VBZRzB3A1qyD0Jxgtod02TyX8kwxJr9o+7RMFlTmuXhBZGCHrPKsY3Va5qIfOrCnWmwRy3Wf7ksk
KGVJX0KbsKbWSksiLpMttp8dYgoUKwHug9qRvbigVYygwXGrWHADoYj6UsKK46+oIqSQgBmN7udE
JFMYV9hBWAIbOwCfxbdZoPcQXi6MpEVZjqgtrKyfePPUE/X2HUvzxOu5nbClyCvP/sq49ZSihr/I
4T73Avt5Cb9jT6wtJGhx6SpoPnuOFOEvAPRJ1EE6lgGAwOsyCAyMIOe76FfYBNXDHJHMAgZvzIfJ
7nW9Rm0l24rYGU9bLwWKZndlWRAr711EpoZaA/w/J3/bdKXb41T7foUmOitOiYfKs0FxY4Q2XKvI
lNhHApED1ThuvF5nqwmYlXbwkEHoBXVvCHA3QCGJB4GdJLA7EfrXcTgNvXWJG8Jbg66YFHX1tExh
YOV4zGRfgVKXhyFug5QTgnU/LDkyzMhvzf0i1eMI99Uu9vH9rm1Ehs+61C805mR0BcJmLM3csf7B
VxqEyi12KL/9H8hMW0WB3YSPH385T5f7sogI7dDeXLM0c2aD0da3Iq/VyE7YhvICiJt1wCyZ3jim
Eix+MQ99XvqkyFxuJOjk3ZQxBqwklw8IhL97E3RpQNdjPPYAaHNkmzB012oO3R97iFiH3d8nVMMg
fNCzXnjUPglKlfszeReSiIja+hMJrmY9lrzuXSDyJ8QWE2Ref+s8yHbt5TYqZZkTI+2oVUT7VJEU
r6H6cbnU3IIxbXni/OFd1h0hmTWM0gjf3KwwE6l2RrNOZ71gLT3FSxMtl6Ov1SwI33l54If6BqbI
KJ6PHMnGT5lLLGnYK3zjpKbbUYfZ3MUN94h9RXXiHt/wpntDI37WsjTZIDlbqdQ8V4C6cqmUTqHj
OXWa9J9IS3tofIJgGlAqCC+BOt3JoUiCcDkrVG9tsW==