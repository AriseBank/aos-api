<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cP+jjmP11j3cd2DfKivciAnCtYNEmF/t1TFe+HlLESAHmHraN9lHzBuoKJcsIloutoECIKkcX
/S9ME96DBtJzKh4nGln9yBF2ikHBwM0AZqC7HRQ7CMjtMzcsRHQN/YeuI4R51lnbANaiimYDPN94
cDh7S+nAgqMMcJig2yJQbEjksi27SEEUVsjdZLzwc7M9P+cVpD96EYE/hu8imwidrdy7raYqpizs
VYshlSDuRSgsuCGOLhzjVCcPceR1bipduxTAjzLFAQ7UPmr51NWHRvV4jjXJiY/EMb34N2BFQq3D
Sp1Ww/+MNl6ZrRBJ/cmRKQFdWrmXpS0mJw29oyY78rfTtJfUBsn0RXphO7yaX28IKvkSL892goqs
TK7qkeMpDpRpKUFd/Gy0nvgzAgvwtll6k1CbEpyRI6RIJRbxRcaOO9uPwwSry6yNu/tn/UVRAeyq
CQiJS5+ZHfbu5XS+6C6S+jq1uCdQ0te56vXYZPa7//oCUnH8+YzGKWNLqLh5aszcTJb9LdWL360j
cCbfuPs57sNlGZXybAWXXzRa/yxnC6Iyijc0o0hWCX95BdUpHgyWWKdx/MdoTLt8vtF+LZe0eOEu
PA0wjsz47jLcmLiFdvS7TX7OS0wNIZ99v6v91zWhINlWK3I7iC0pCoCE388fjzK6gHwYYuKiIQiT
qGTBVfe68WYKhm+j9n6wUPij9/GiY/ty0mvgw4QBEG10STHkDryK27S/kIFv3nlnWn5kQGgxUBZx
JnuizXQAFsLkonZtytWQCp4QKTClIW9mO8JiiuuXqW7l1OaLwp+IBwEk0cCcMdsUqZk/oaFuBwv1
+DoAaoLMAQOiaPiRFcgOUtV2CXMWxbzdR/VAlePaWZUQ3OikPX3KmIE9KclvVDpFyuT28cYjnICh
jmaMynjWGQiGSS/NxZd8ZpOI+E7bKUS4oQ3MvGwo