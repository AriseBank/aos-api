<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPx6z9xj0X9oy2Ggoc6EgtDmpamI216HIAh+i5zzLl24b7Yu4nNscfaAtTMd92GtqzVqxhWn7
j26yo5LHwZXxdwoQ1utWg8adZaPkkuNBpF3v7HRbLIhmKorQ2LBNjx5NyEg5+7baV4sAhoVTiG20
LoHm2awN6mR3BarO9czJ9mh+vYpeEUj2GuTDI2HpkrSxY0s+hBAfTVhP0gixxWMfke+TYrwLLjWt
mBVgY804ibI+dfBSMpbgoPcQXi6MpEVZjqgtrKyfeTDX+T42kvXwahbrtbC2zCur93SX69SNe+xV
k+f/z8/kdmM8sAFjAr8iuQ3s1eZRJYfGEkOcEfKLEWnhxZWQRe27Dm/JJCoQV3RD1UbJ3lVIyXYh
LbUT5uF5HZEqbk+Jz30UWsk8cYK7fhmeP2F/Bj9q0Qo94/tTodqxGIPDDeNhUOlNtfwvCJ0Y0mBB
p2k7GLtQQUQcKcVKBULsGxHwE2QDTwQzICYv8WbA1pcvZQfrmjRoSza+SemELYor41mlwKHLozBN
/0YyVIgXsSMn16g+kWOq1YMLiZhHFpwg/gDD7IH6LMvW3Rv8QOVM5bSDwb3jI1/Cq01EAkTOW/VR
SShOOamK7TvzJwrA9tvstOnKgSXC1sqPRJ//hhbOv0521eQAh9xcnfC8fWj/IR/1voD9Zpd8AOtW
MmUkuv8aAg26PkFhBn2b0TtAs1j74V6g8pDV+Myp69jLX7QK0ntPNmWibI08HMWkWV5k0n1JzqtZ
5I1gc9bWaczSkwInJeO5sIwKR32BHQ9fizWJYK4wzY2YN9B+SqNGwxD7/+wfOD8JMamuI59dqvG1
LeaOHHUZOVpx+KHD8Q08TVUNdQ/AvFQR+VWJ7kqWj9VShiDHddFujXLyiZCKqhfPmhAbJj9rwVFm
0+pDyExt9N9KkfVhjHWOtfcGTNKKuyKd62O18xA7LW+Wr/f1M4RS3O1NlBqY8TTWTUK+ypbbBW7L
ZdGo19XDKkEw2/yb9NG=