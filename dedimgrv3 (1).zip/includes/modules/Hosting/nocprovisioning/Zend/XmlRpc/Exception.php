<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPxvjEusDjv+YNDgkhf77zc9X1N0qMqyHO8Ii9g0jysDZbd8ZufgDmi7EBFyO4HTpsXKzyMi2
lj+mgQ1nqHqNnP5+Q1AkrFTTN3MLbLxBSyquNR/JoQqXU21+XPOE9RVLcH0z541+bolzcq92kdO5
D2mxjjK2gw1U2V4A0Uoh+klNPMCohjSpDuw5kokrEeg0jHH7I7TohJ4nUcteUpiRf6ya9Ld+FvNo
dBqzerOPuRefXdagFNEnoPcQXi6MpEVZjqgtrKyfeVvWLvgc9XglZKDhBbEcTCzmLZjRYhAihOmE
S4Nf9Hs4Vnu82oi0owmYzLBEa1zUikfG6SB9Aff2QEq1P6aogLgyAAIyXVrsQUOVQSV69oV7cE/X
j4hqt/6SQ0oBZRNqKz4NWAe7fuiQa00kg0mlT0j1hBKbTBDzsmE8jgGDZnQsPDWfvuYaJ1hGXwb4
vA0YaMLLcEkhvuxXgu8MRJcueZyHN25TH54s7NoBLGiEatZw0lvdCpKN1tVCE10MqO9y4YDSw3SO
e9/cLEAD3xo11qSZnRfXH8wFmUCDxqzSa8098y4xui8nxKIQSsMV7w3MVWPaV3Pqvw70UFw1Qt64
H1rwnZUKCsZ/5iTnkuAO3jSh4vLeb0IhiWGR/pdBhIYPbqjveanC0IRMNLaiqoXNnrY/KfNWQGuV
6SQv1Uzt6nPkL8p+05gIBJLGLqYQyOCqQRFAyhslku1DP+rSKbnbe8B6jIPXvWmBtaHIgNQL2QLe
xvSfzFfAP9xiCMv8CwcsfvGRMtWMGTkdFcWY/Oln8gDWFer+BLGXC9azQN8AnoI7EEvUEIIvTz2c
AHxR2in5rOt7OpPX07MxPWjDC3fAdDf1XE8gDSkhpgeaMaXmqEB8kguxnwFq5cdJUgNhN7Wu7z86
WCwXXhyfqyebPfbPf3+jVNQme9/DkjtFhRJcWxq=