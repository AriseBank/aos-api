<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPmQf3TFATVRaXncOy6kptcKelseV+eTgk+XYY2Jn1KTmOWotTUDJ1aSfGAaTJ+uSzzNF2RH5
3H/ktrxXolwACKMzrwVv0X8v8A63SAYdXudnvros/25RvKoTj6K0RDNiI0/KJ0nMqPVsWbZRyRwu
XRYxPPdzgAquWSpqn7gsIVJ3Xd1dcIeE7Hj1aS99l+/6a9VMTuhmeEdOb7ig4g7/UDIPuG9J3NX+
iSY4rgVVf4TgErAg4shE0icPceR1bipduxTAjzLFAQ6bQyCXx5fXIKQ8Vc9JfdJFRhEDwvwGsu3b
bYM0nc3AeJ5aKKpY2rOzNkB47gRmJUZeFxAioXfUvUbgpAwUJ0aptxTzbcKeSUdvFTHU8clxudL9
muwj/HwW/2hoyc35kB/CYBB0US9phVRex13MOrd1HxVo2FTXSxwnB4GYOhYnEA05DRz4R3QhB5Sf
vwsozeZ6SbP08+c41tgoxW0rXsHfGH3HONwAttROU/1/2ySC8XanDJ22uxptkV+Im3BhqQmreLqA
jOu+BakVmqIEkEebxJPGQ2kctK9A7tKs9QJ9Xe0fMYOds9DRNoYW6ZhANVD+esL69WMGpNR/X+SO
c7XJCQoWG2DsMqDIf0fjisXgylYeq2q5EUWxOADBJN1G3u9gMpkEx8AXJJIKWVU8tCHlWkGngA5i
qYh3715mfrZNeaTtK5C+UcsFRCcxpO9c3uL1KiM36kV/QWTOKFcu524Up/MJUsjdRiOa76HQUAwj
iJ+aT77+b0CHrndSdrWWEDV6zRTx0uqBsu8tgoECCV95UqUAf62tDzus6J6HkWomKNbcRra3TRGb
m2PxgxWs3lT2kK98Q1JTrnBG+4/uZxdh0UjlU+Wz/tt49PoxrzhJuw6xBuj/c5FLlX85noJ4998p
d3HWwi9/kSdkNnwyKPes1y6vqbUeTONskWIy7YE8gZx/HHxcRBRTi8riZAq9xgyIkMRrDJ/RPIB/
2aOqhugqTxUl1rFZXP8uSsyWR7/LEF5KtlofxKWOCopBJhl31zdoCdz1DHRvcfQCZh5tIgD9k8dS
QZUXL0daGwNAyGRPc2C0CZJ5DOIQQ9dH6nWNL6G/J+CMe3PMP591M6rXSzJvcyjz/4vWTKTv5TLQ
5a6aREU7uSuH0W3aaiwY8Q7/5u2nQmIrDBJCIKfKuAZSuIQSxXUC5S1TkUWicFv7jqfVQ9mNceY3
o6/qKwQYCuQjvuGGCIWPdLtagDskyesd9SmFYIqbKNmMnbYAU83UAp9dcKNqcj4kTR295sYvA3WV
KtzPhF1LwnnuXcKNI8AFNEHaJ6XNH3ai755dH06ej7Q1cli=