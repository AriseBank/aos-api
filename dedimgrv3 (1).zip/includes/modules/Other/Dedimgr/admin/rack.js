(function(a){var b={verticalOffset:10,horizontalOffset:10,title:!1,content:!1,url:!1,classes:"",position:"auto",fadeSpeed:160,trigger:"click",preventDefault:!0,stopChildrenPropagation:!0,hideOnHTMLClick:!0,animateChange:!0,autoReposition:!0,anchor:!1},c=[],d={calc_position:function(b,c){var i,j,d=b.popover("getData"),e=d.options,f=e.anchor?a(e.anchor):b,g=d.popover,h=f.offset();return"top"==c?(i=h.top-g.outerHeight(),j=h.left-g.outerWidth()/2+f.outerWidth()/2):"right"==c?(i=h.top+f.outerHeight()/2-g.outerHeight()/2,j=h.left+f.outerWidth()):"left"==c?(i=h.top+f.outerHeight()/2-g.outerHeight()/2,j=h.left-g.outerWidth()):(i=h.top+f.outerHeight(),j=h.left-g.outerWidth()/2+f.outerWidth()/2),x2=j+g.outerWidth(),y2=i+g.outerHeight(),ret={x1:j,x2:x2,y1:i,y2:y2}},pop_position_class:function(a,b){var c="popover-top popover-right popover-left",d="top-arrow",e="right-arrow bottom-arrow left-arrow";"top"==b?(c="popover-right popover-bottom popover-left",d="bottom-arrow",e="top-arrow right-arrow left-arrow"):"right"==b?(c="popover-yop popover-bottom popover-left",d="left-arrow",e="top-arrow right-arrow bottom-arrow"):"left"==b&&(c="popover-top popover-right popover-bottom",d="right-arrow",e="top-arrow bottom-arrow left-arrow"),a.removeClass(c).addClass("popover-"+b).find(".arrow").removeClass(e).addClass(d)}},e={init:function(d){return this.each(function(){var e=a.extend({},b,d),f=a(this),g=f.popover("getData");if(!g){var h=a('<div class="popover" />').addClass(e.classes).append('<div class="arrow" />').append('<div class="wrap"></div>').appendTo("body").hide();e.stopChildrenPropagation&&h.children().bind("click.popover",function(a){a.stopPropagation()}),e.anchor&&!e.anchor instanceof jQuery&&(e.anchor=a(e.anchor));var g={target:f,popover:h,options:e};if(e.title&&a('<div class="title" />').html(e.title instanceof jQuery?e.title.html():e.title).appendTo(h.find(".wrap")),e.content&&a('<div class="content" />').html(e.content instanceof jQuery?e.content.html():e.content).appendTo(h.find(".wrap")),f.data("popover",g),c.push(f),e.url&&f.popover("ajax",e.url),f.popover("reposition"),f.popover("setTrigger",e.trigger),e.hideOnHTMLClick){var i="click.popover";"ontouchstart"in document.documentElement&&(i="touchstart.popover"),a("html").unbind(i).bind(i,function(){a("html").popover("fadeOutAll")})}if(e.autoReposition){var j=function(){f.popover("reposition")};a(window).unbind("resize.popover").bind("resize.popover",j).unbind("scroll.popover").bind("scroll.popover",j)}}})},reposition:function(){return this.each(function(){var b=a(this),c=b.popover("getData");if(c){var e=c.popover,f=c.options,g=f.anchor?a(f.anchor):b;g.offset();var i=f.position;"top"!=i&&"right"!=i&&"left"!=i&&"auto"!=i&&(i="bottom");var j;if("auto"==i){var k=["bottom","left","top","right"],l=a(window).scrollTop(),m=a(window).scrollLeft(),n=a(window).outerHeight(),o=a(window).outerWidth();if(a.each(k,function(a,c){j=d.calc_position(b,c);var e=j.x1-m,g=j.x2-m+f.horizontalOffset,h=j.y1-l,k=j.y2-l+f.verticalOffset;return 0>e||0>g||0>h||0>k?!0:k>n?!0:g>o?!0:(i=c,!1)}),"auto"==i)return}j=d.calc_position(b,i),j.top,j.left,d.pop_position_class(e,i);var r=0,s=0;"bottom"==i&&(r=f.verticalOffset),"top"==i&&(r=-f.verticalOffset),"right"==i&&(s=f.horizontalOffset),"left"==i&&(s=-f.horizontalOffset);var t={left:j.x1,top:j.y1,marginTop:r,marginLeft:s};c.initd&&f.animateChange?e.css(t):(c.initd=!0,e.css(t)),b.data("popover",c)}})},destroy:function(){return this.each(function(){var b=a(this),c=b.popover("getData");b.unbind(".popover"),a(window).unbind(".popover"),c.popover.remove(),b.removeData("popover")})},show:function(){return this.each(function(){var b=a(this),c=b.popover("getData");if(c){var d=c.popover;b.popover("reposition"),d.clearQueue().css({zIndex:950}).show()}})},hide:function(){return this.each(function(){var b=a(this),c=b.popover("getData");c&&c.popover.hide().css({zIndex:949})})},fadeOut:function(b){return this.each(function(){var c=a(this),d=c.popover("getData");if(d){var e=d.popover,f=d.options;e.delay(100).css({zIndex:949}).fadeOut(b?b:f.fadeSpeed)}})},hideAll:function(){return a.each(c,function(){var d=a(this),e=d.popover("getData");if(e){var f=e.popover;f.hide()}})},fadeOutAll:function(b){return a.each(c,function(){var e=a(this),f=e.popover("getData");if(f){var g=f.popover,h=f.options;g.css({zIndex:949}).fadeOut(b?b:h.fadeSpeed)}})},setTrigger:function(b){return this.each(function(){var c=a(this),d=c.popover("getData");if(d){var e=d.popover,f=d.options,g=f.anchor?a(f.anchor):c;"click"===b?(g.unbind("click.popover").bind("click.popover",function(a){f.preventDefault&&a.preventDefault(),a.stopPropagation(),c.popover("show")}),e.unbind("click.popover").bind("click.popover",function(a){a.stopPropagation()})):(g.unbind("click.popover"),e.unbind("click.popover")),"hover"===b?(g.add(e).bind("mousemove.popover",function(){c.popover("show")}),g.add(e).bind("mouseleave.popover",function(){c.popover("fadeOut")})):g.add(e).unbind("mousemove.popover").unbind("mouseleave.popover"),"focus"===b?(g.add(e).bind("focus.popover",function(){c.popover("show")}),g.add(e).bind("blur.popover",function(){c.popover("fadeOut")}),g.bind("click.popover",function(a){a.stopPropagation()})):g.add(e).unbind("focus.popover").unbind("blur.popover").unbind("click.popover")}})},title:function(b){return this.each(function(){var c=a(this),d=c.popover("getData");if(d){var e=d.popover.find(".title"),f=d.popover.find(".wrap");0===e.length&&(e=a('<div class="title" />').appendTo(f)),e.html(b)}})},content:function(b){return this.each(function(){var c=a(this),d=c.popover("getData");if(d){var e=d.popover.find(".content"),f=d.popover.find(".wrap");0===e.length&&(e=a('<div class="content" />').appendTo(f)),e.html(b)}})},ajax:function(b,c){return this.each(function(){var d=a(this),e=d.popover("getData");if(e){var f={url:b,success:function(b){var c=e.popover.find(".content"),d=e.popover.find(".wrap");0===c.length&&(c=a('<div class="content" />').appendTo(d)),c.html(b)}},g=a.extend({},f,c);a.ajax(g)}})},setOption:function(b,c){return this.each(function(){var d=a(this),e=d.popover("getData");e&&(e.options[b]=c,d.data("popover",e))})},getData:function(){var b=[];return this.each(function(){var c=a(this),d=c.data("popover");d&&b.push(d)}),0!=b.length?(1==b.length&&(b=b[0]),b):void 0}};a.fn.popover=function(b){return e[b]?e[b].apply(this,Array.prototype.slice.call(arguments,1)):"object"!=typeof b&&b?(a.error("Method "+b+" does not exist on jQuery.popover"),void 0):e.init.apply(this,arguments)}})(jQuery);

$(function() {
    
    $('#sortable tr.have_items').each(function(n){
        var that = $(this);
        var s=parseInt($(this).attr('size'));

        if( s>1) {
            var x=that.next();
            for(var i=1;i<s;i++) {
                if(!x.hasClass('have_items')) {
                    x.remove();
                }
                x=that.next();
            }
        }
    });
    $( "#sortable" ).sortable({
        update: function(event, ui) {
            var total = $( "#rowcols tr" ).length -1 ;
            //re-assign positions, save changes
            var i=0;
            var o={};
            var size=1;
            $( "#sortable .dragdrop" ).each(function(n){
                size=parseInt($(this).attr('size'));
                $(this).attr('pos',total-i);
                if($('td.contains',$(this)).length) {
                    o[total-i] = $('td.contains',$(this)).attr('id').replace('item_','');
                }
                i=i+size;
            });

            ajax_update('?cmd=module&module=dedimgr&do=setnewpositions&rack_id='+$('#rack_id').val(),{
                vars:o
            });


        },
        handle: '.im_sorthandle'
    });
});