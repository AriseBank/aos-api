<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPyBbuqOqJDXfrL9sPK9c44OGkomd1bE2OfoiPYvX63V2xmv8keHgUn1U/dOSzgwKVyK0NuHu
Q1EdNV5g6jjDW6JBCBYa2RFPuPXEYH/Bqj+0qboxznjcnnAwt+LTyQ+91wmYMD1XZ7DX8w054Zc9
HEKXyGr/HQ1s2GAfgxD28zS3I90PWgBxP1qx/a3r76aiT2qUyGZ63+ChsX2D0Fh8rftBkPWg9cFv
BMhVcv4p6Co+OicW5N+CoPcQXi6MpEVZjqgtrKyfeI1WGZ7LZsQHu/JSPbEcTCyJsNYQkXTIjaU0
LkJvQ3FcUASm8Vz8ejEQLfbz7yElY6scnsXsZzRMhHoenNyhWFUzRF/rznI37BJHjq2cUxnjt32R
SO2anJ6Wa4mQNpv1vBi79pSrB7CdZuL47614e2XdVIdkT14zlGCMzYHMA4oI66FlENrcePqfzJR6
dwqapSCL2Ox/XhK7e4L5T7Z38FQZd0E0A6qCMcCTle47YjkD1q5jh4TIxiTVLtUFXsGn6zS/vvIr
7fD402x43OHdW5c9cb9a7v/JcsqM25jwp8N4TcXd4KOzooUEnzgJCcOb985Uf16zVhbq2Gv5EfD+
WvoBq3rE48errMLqVKwp82l4Rxn6C6h/5x1ukAMVA4hKjDeV6UAlJDVl+sz/vct8KsXFy2bX3f/e
+GADpO0Z3l4C6kXnqY6MSlJasUgGGS2iQVBo60sDDqi4+VVYabEvr+V2cdEGajWmWGjPKm3vxSpv
gJyA7RypopkcpzrMOpUSGDVoE4YJRpRfyQx3ElgKtz3Nl0BXxoKAMd3xOFaPbF6fP1GKrf+l9sPL
Orjdt4z+hJNvsoGkas6IurwwdsKM+uDZU2ECT88vcI3rfBUiB/U+sjFmrlYH+WDtn0WGNzLTTfjq
ZpXvSjGkE/Z/thbrES9qv8iXWdafG3hyxKzXTkBGcTgFHNAM1iBKBsKnjDfqIK1x7QK68My6IcCj
KmpgTicTMmuDfS0f6UgTcti+zBfhSaTvZu+3I5FxP0+AJAjp65JSlLlA6MXib3aRJ1IJGn7rVotH
IeQ7ebfsiPXnikvwBOdGAp3I5Lz8D0nTlQT3cWwSEDFyigHDoKNNXVIXA6YgO9YGdcsh/nOq/VK=