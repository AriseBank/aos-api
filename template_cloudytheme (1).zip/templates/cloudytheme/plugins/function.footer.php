<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPyQMG38SSha5pI3L4OjwrmdyNvYqlIf7kesi+48AWW5dm6tPX8HbRQvMoNR/gMHvDKEmMf/W
tml7Z7HodoLFobrHBGIgJMEw7ELHbFeQrwzrXlVyju8ItiQcEYgvWtLp/oahLAxu0XVk2yeL7HPS
JIVuU7nC5e59UjvtgT6R0A2nyIcFVOBdvOEYD5NshbhF9oY8Fu+7a3LZP/hHYGinAIyWt8m5S/96
1TJwPlMJWn7rOCTb5HGd6hpIidwyKE+JI4X5xw/JOOjXwDaR9BKIq/p+OLKiXSyC/ruL44Ismx4c
iHB2iPzn83dzWn/kJJbzxsbPvsqNxjneJ/ILkBftzdOdc/DamVdUT26aliLsWk0ttOu9xVylLPVs
0NJrbGA6wLhQWEmtglCSBfba/CG08ha+qzWc36o/i5teTd0lHurGuZOMwyU4EvfX2geZF+2Z1kVz
GO1NemMPjXNoRWEqiMXkCR8kWa9YzkQATNNwPd0jdlzeFMQmZ+O8pPp5vBjJR1G8cDGrGbIDDKyA
iG8qjMlyF/6m0nxk0pHgMQllniqYeYq8x0i6vU9q0IOv2aBlgpFQGTskjJInX6isWKSaOqaDutmH
8i5oAR6Bx+ShL3V9l/1Ji94eyGs0KvhUPIQeCL8APLskvllWDBlVC9lM6ZHFFX2K4hBo/4DklkKg
831Oyo3RwxYMl+wBMKAgsA9YOt9WnCcVLKx63VU2TsZxBQBLgLM4S/1DdKAEIelZh2hmNabnfleR
N2JRZ7SNKvISZxDoKFdotC0ajRVuzfYjYPoT6js3xl5eZoMqbyMeA0==