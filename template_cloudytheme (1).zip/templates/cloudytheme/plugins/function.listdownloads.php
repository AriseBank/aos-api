<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPyaOQQONu56A+gxyXSHRcUshyz5MT7iO2k1mO07lXObsw2rCrt3+LsRbk6g8dmvietqXI2tk
ZB94yKhOdajordh/3Ola7m05yADbswGVqvoyRLbfu9D3N11e3Spzcs8enXotF+2Eah9ZM0xVlJiu
FmHTww41XsurOk0K+UPIuXpfufqt2svXgrHOoSyHQqCXomDpB/6xa0KH8opom+AOAP0WkHBAOQLV
I8kPV0kcmt78niweuPtl5uCQlDAoVhnGxvD8I4NlhzDX76RoPdqYKx7SmCajLU3tpW86fxpA6XR1
WXGEIBKKOQwuCa9Agel42yiZTQmNHLFlvudQjZ5NwJNIcDOfPvg1qSxylOIHrRcKxWNsGHWHC9Qv
0sZF67teja4edHpeeCqTPfco6uuS6q6ikIC7EoLgR3HigbW9U80vxc38f+gzjxRLEFnkVBa+XrVq
FnoFbPMqQE/4jUW0MIhOGVt4w/wPW1D72DG+o6B0Lvi0OMtYkf8QiRbhr1wuU3231ZaBo0dS5BIx
M7ui0C6fYvaJCIqecumukQMhiW5j+VxvYgdvnKwlKVNsMSwJO0CSfXRrfV91ZJbQUOZULDsg8lXT
o8DPmqYFjrZwSU7GdbjDICpVwAE1456Xhenv3GyD8azXQ2npNIy5MuUfqcI4qUnUWFn6zfMZlN7J
OUiJd/gNc9/QHJPfoohJoWe02NLbUPASQHBVbhSTst/BvYcceB/MkIHpBt43vX60NcsE4MIQWivG
EhdL+qlM1OwQEcKP6uOXaLHIm2WTo13T9lz7jiiXGg0h9+m5q53c9Le7ABnusttomTsLZKZF+sQb
/eYenSjkj0==