<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPr513OYuglMlKVUOgrWqXMSwWGNEvkDY7kGFHYc/4UrXNpyqoe4cwgzczpP80xRcHIf/ELw+
6RMrNyDMa4diJ2K4fCa299j6sHAcNPE4RUQoOvQgIl+rgVE3ltrDXkD1siBy4PIApQwASlaGnDWN
Hyxmg9Gge5DofXps91qb7pG72f4/qXtmCBFwVv7uxlXi0/pM/TFiMcR/vTJCx/m4+19XG28G023W
0t+TuShF8u2qxkDsR6+ph+Ru6hpIidwyKE+JI4X5xw/JOGbgzXVNGAcIiGhTpLNWzyvS/pUgK+/l
q/K4/ANkTd/yMQeBk4dLhJhUX3XTTKmzxLPZEdsf2xOvhkzJLxscqkijN7GHf/WXzBdwPmL5jDAR
Ooliji763m7MGKIMq4i7BiubtBQt82plFsC1m218n0Ng1GrU1at4qQaTqqy2mVxiBCn3A/NnrHGM
PFwcQkSr0idg+Ac3jOCaYERiPB8wzFu1Wb8iZFHb8OzrBif3QxPEC8/eCVEn9m2sMtj7XEsAIO5M
T4tmG/G6QX6O5HmB5wFpq3JDgeb9ogQ0g+5h2XEqpLTZIM+3ahGYtHZsclSWoM0ltzwlhcAirMMy
QMndKA5T090hyPoQhhz6JJJU2Vlw7p+5nWJu69TBW7ZDndgBPjeJ7ly3tdt4E5aR7mDcIv0bSOVH
hKr5P0E1wKXGhFxaRbIyCXSoOdaunE7woZv4X7z71/qUZ6IOPAlZEqNOetilMLP1xfV86LpoXGKB
wY42wNvsBVD3TIDMSPXl5BVNXSWDimRwYUIXXHUa2LJXYW/7vmL/vUTeOx+dml+RIW==