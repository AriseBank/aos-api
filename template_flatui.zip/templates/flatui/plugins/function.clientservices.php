<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPy4Z8EaL2PdEz9MrocaGTOpXN4Avx5AxJ8kia6j/2syYwGLX7GYZtp9CMuM6G6olYfp7nP0O
A7VFq9iqcQGNSQEbNa9Bb9cMnZvSxN9MSV9zHsuUKrfGH1rRuz+6MzgYfl/0kSsku/KvWrAFcDeG
O2wLdo48fhGjsVrHTFcwpa0mBv+oxTgibJEiHuswTBGqbFdml06ub6gS5uVUnxP0zYlpg3Xc+x+o
uF+FK7V7B0w6mGVvn7k7039EFbo/0K3jWFC4rOrhme1cHke6NiSN17bJuFV9oj858tlnPHpc2b6n
ChQ3PGgadhbRIXUfMNK6zVn1KgThJosa1iO8XL5yZEwQBbl1BjSeGgQDWdw7NKkWAS4FeNplA78h
18E4lH0XCZSU4IgaiNNRehZF/c6pfxSESfqkPOQqlNppRf3RcP5unlJRbtF7B+uTZCaUDdzxw2r3
LBonsw457hzeZTJ/bL33mS9382PoWLLFnPoKEgdrpPyHjMKPAbQBfHxhrF0cuW281DpFUZRF0i6t
d6ChJk7B1AYAQ2R0Cy2jGmP74AXMtT/5d23Dl7A6zRUOI37ooBpK0Rt6SVp3nrN53IUlbMhT+Kbf
OptQLY87vpX69hAvNCFo3jAevwB3tOemu0UGg8c81/v3+oygpN8mrZ87U2aNbsMJJ9MgTLO/crNb
gve3e1yF3xLO98WRGNxqNhKmUn2cANfihvNWvYwN2VelUnKLwe87yQdJ4KmzpdSfBwgLNsV70gVM
46Itg+iuXHfJbAxxKNTqtJbvohmUyTwPfcGHFLgbdCxp9SzE4duNkjmwYM9+pR3o79+reInSek2b
frx9jKO=