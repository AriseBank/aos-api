<?php //0084e
//  HostBill - Client Management, Billing & Support System for WebHosts
//  Copyright (c) 2010-2016 KP Software, All Rights Reserved.
//  Version 2016-02-05
// 
//  This software is furnished under a license and may be used and copied
//  only  in  accordance  with  the  terms  of such  license and with the
//  inclusion of the above copyright notice.  This software  or any other
//  copies thereof may not be provided or otherwise made available to any
//  other person.  No title to and  ownership of the  software is  hereby
//  transferred.
// 
//  You may not reverse  engineer, decompile, defeat  license  encryption
//  mechanisms, or  disassemble this software product or software product
//  license.  HostBill  may terminate this license if you don't comply with any
//  of the terms and conditions set forth in our end user  license agreement
//  (EULA).  In such event,  licensee  agrees to return licensor  or destroy
//  all copies of software  upon termination of the  license.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPqScG9+x3BdGLf7Ll5axdedU5wUiGFBkACTniDWWBFkslFLw2zHgSam9OBLGrgcrsku12EAR
vQ9sj5M242GkGQOZnIXSvsPBxzBUFr3Ds0yYdhgt/2HqLVJee1tJugUh3Ni40DD84W3Xo0ORoaVj
4nRUicL6zhZ9IoJsu076KR3bmqbi38M4JiN6PJBK9620DegqHuNjFhF3YcIhNTPvAqX1v1BVP5HY
RBzECpKzc2zSKAyLlEwqf6u0Cau+NBy1GEs0ymJLZMl2VcFM5AhM133wk6BFPy0SpLydQlR0NkpP
KCiDr+CYmXqJozPrSMO3xgMQLQPi0jE/jZsd+y0aolhfdzbyPe1bmnK/CL2ANnfhJWFFYR1PymRr
Ha+Z+JJcQUR590Jo5OpvTgJfCLR5+//3MqXT5OVqIoZpZ39uZGbsFXC8jwAgFNOZk5Q8uxCQVkjF
zK2lPx95Ndkx+hUhak6WZf68+1sF/Mbf4fnM1d0LEnDNSITZKPM5jzfuoNnNM0HD3l4nFVnR3T88
HtyVrM+ruOl6IVc/+6BbdZV34dYSvnzODYZhS48UOC3lZnktSTLL0I/XbsGjc5L2mdz4IXSVbNYk
xaXo0ZZ+CxBvpXAnKPIuRA8KT/68ADx3kld51F+Z88jVlrHKUfzgc0NtsiSS81bwI7P8Xudw1/W6
PTZKDwsnJvNbL4cGa/Ar5k91S9rW1wNINkpUUYROQsPXjo1fRL+ctcwqP78VYafu4y/vwjYgq0+T
nE64Ukax3lzbNAxxVwwD8ldiPtBIlpZGB7LSl1poKT/ALIqXs2/q9Jj5AvvQlb1fXK0ZrKQGJqSB
7EL8akk5Z2lV0QuZeDJnO/T3EuYiy0rV9LIKMaa4qJlu96CrkUiVmCFvZC2KEvCs1sXl28BS3UDR
+7i0OnYc1UIgS4IJ0/vqwEjJbFXXwAAt1T+JfVvkKm1aSPhRwsln8JYLLjQ0pEwOUUE9cSJC9gX8
NblNkCgWVK1GoyTM8ms3jvxXUhazGGRbaP3tAOioMHs+yzAXDLUDpuBWc1WLZbVRzX69UwZVjauU
yAZRIPISzR7gVps1iCi0rh2B6SR2dZXQ3Fby+HqEyAYOl/mg18U83LKFgipRjSmQwXFz2YIQEtkz
lEv3jcm=